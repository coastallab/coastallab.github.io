clc
clear

d = load('./m1/bottom_20sec.dat');
d_bsm = load('./m1_bsm/bottom_20sec.dat');

exp1=load('./m1/exp/xia1.txt');
exp2=load('./m1/exp/xia2.txt');

ex = 1280;
ey = 74;

for i=1:ex
           for j = 1:ey
              if(d(j,i)<-0.1)
                   d(j,i) = NaN;
               end
               if(d_bsm(j,i)<-0.1)
                   d_bsm(j,i) = NaN;
               end
           end
end

dd=d(1+5:74-5,1+5:260);
dd_bsm=d_bsm(1+5:74-5,1+5:260);
x = [0:0.025:1.6-0.025]+0.025; 
y = [0:0.025:254*0.025]; 

   figure(201)
   mesh(-dd_bsm);  
   view(30,45);
   
   figure(202)
   subplot(211)
   plot(exp1(1:2:162,1),exp1(1:2:162,2),'.',x,-d(6:end-5,85+21),x,-d_bsm(6:end-5,85+20),'--')
   legend('Exp','Num','Num w/ BSM','Location','SouthEast')
   ylim([-0.2 0.02]);
   title('Sectional Bottom Profile at X=2.5m')
      xlabel('distance from side wall(m)')
   ylabel('Bed elevation(m)');
   
 
   
   subplot(212)   
   plot(exp2(1:2:130,1),exp2(1:2:130,2),'.',x,-d(6:end-5,85+61),x,-d_bsm(6:end-5,85+60),'--')
    legend('Exp','Num','Num w/ BSM','Location','SouthEast')
    title('Sectional Bottom Profile at X=3.5m','Fontsize',10)
   ylim([-0.16 0.02]);
      xlabel('distance from side wall(m)')
   ylabel('Bed elevation(m)');