clear
clc


%% Load Num. Data
%bn = load('.\kl_brk_van_fulldepo\bottom_f4.dat');
%bn1 = load('.\kl_brk_cao_05cf\bottom_f4.dat');
bn1 = load('bottom_f4.dat');


%bn2 = load('.\kl_\bottom_f2.dat');
%bn3 = load('.\ks_auto_diff\bottom_f.dat');

bm1 = load('bottom_f.dat');

%% Load Exp. Data
be4 = load('.\exp\k_bathy4.txt');
be8 = load('.\exp\k_bathy8.txt');

%inital bed profile
xi = 0:0.1:14;
bi = xi*1/12-0.8;

figure(8)
subplot(121)
x = [0.:0.1:200-0.1]-180;
plot(x,-bn1(7,:),be4(:,1),be4(:,2),'--',xi,bi,':');
%plot(x,-bn1(7,:),x,-bn2(7,:),be4(:,1)+20,be4(:,2),'--',x,-bn3(7,:),':',x,-bn4(7,:),'.-');
xlim([-0.1 14]);
ylim([-0.5 0.5]);
legend('numerical','experiment','initial profile')
ylabel('Bed elevation(m)');
xlabel('Distance from Gauge 1 (m)')
title('Bottom profile after 4 waves attack')

%figure(82)
subplot(122)
x = [0.:0.1:200-0.1]-180;

plot(x,-bm1(7,:),be8(:,1),be8(:,2),'--',xi,bi,':');
xlim([-0.1 14]);
ylim([-0.5 0.5]);
%legend('numerical','experiment')
ylabel('Bed elevation(m)');
xlabel('Distance from Gauge 1 (m)')
title('Bottom profile after 8 waves attack')
