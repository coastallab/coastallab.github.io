clear
clc

ts = load('ts.txt');
ex1 = load('.\exp\k_eta1_re.txt');
ex2 = load('.\exp\k_eta2_re.txt');
ex3 = load('.\exp\k_eta3_re.txt');
ex4 = load('.\exp\k_eta4_re.txt');
ex5 = load('.\exp\k_eta5_re.txt');
ex6 = load('.\exp\k_eta6_re.txt');
ex7 = load('.\exp\k_eta7_re.txt');
ex8 = load('.\exp\k_eta8_re.txt');

%plot(ts(:,1)-1.083+43.9,ts(:,2),ts1(:,1)-3.134+43.9,ts1(:,2), ...
%    ts2(:,1)-41.45+43.9,ts2(:,2),exp(:,1),exp(:,2),'.');
%xlim([40 70]);
lag = 41.25+100*3; %41.35;
ms = 4.5;

figure(411)
% subplot(811)
% plot(ts(:,1)-lag+43.9,ts(:,2),ex1(:,1),ex1(:,2),'.','MarkerSize',ms);
% xlim([40 70]);
% ylim([-0.1 0.25]);
% legend('Num.','Exp.','orientation','horizontal');
% ylabel('\zeta_{ G1} (m)')
% %title('FSE during 4th wave attack(Cao)');
% %xlabel off
% set(gca,'xtick',[])

subplot(411)
%subplot(812)
plot(ts(:,1)-lag+43.9,ts(:,3),ex2(:,1),ex2(:,2),'.','MarkerSize',ms);
xlim([40 70]);
ylim([-0.1 0.25]);
ylabel('\zeta_{ G2} (m)')
%set(gca,'xtick',[])

% subplot(813)
% plot(ts(:,1)-lag+43.9,ts(:,4),ex3(:,1),ex3(:,2),'.','MarkerSize',ms);
% xlim([40 70]);
% ylim([-0.1 0.25]);
% ylabel('\zeta_{ G3} (m)')
% set(gca,'xtick',[])

subplot(412)
%subplot(814)
plot(ts(:,1)-lag+43.9,ts(:,5),ex4(:,1),ex4(:,2),'.','MarkerSize',ms);
xlim([40 70]);
ylim([-0.1 0.27]);
ylabel('\zeta_{ G4} (m)')
%set(gca,'xtick',[])

% subplot(815)
% plot(ts(:,1)-lag+43.9,ts(:,6),ex5(:,1),ex5(:,2),'.','MarkerSize',ms);
% xlim([40 70]);
% ylim([-0.1 0.27]);
% ylabel('\zeta_{ G5} (m)')
% set(gca,'xtick',[])

% subplot(816)
% plot(ts(:,1)-lag+43.9,ts(:,7),ex6(:,1),ex6(:,2),'.','MarkerSize',ms);
% xlim([40 70]);
% ylim([-0.1 0.27]);
% ylabel('\zeta_{ G6} (m)')
% set(gca,'xtick',[])

subplot(413)
%subplot(817)
plot(ts(:,1)-lag+43.9,ts(:,8+2),ex7(:,1),ex7(:,2),'.','MarkerSize',ms);
xlim([40 70]);
ylim([-0.1 0.25]);
ylabel('h_{ G7} (m)')
%set(gca,'xtick',[])

subplot(414)
%subplot(818)
plot(ts(:,1)-lag+43.9,ts(:,9+2),ex8(:,1),ex8(:,2),'.','MarkerSize',ms);
xlim([40 70]);
ylim([-0.1 0.25]);
ylabel('h_{ G8} (m)')
xlabel('Time(sec)')
%set(gca,'xtick',[])