clc
clear

opengl software

xyz=load('bathy_cc_wide.dep');
nx=600;
ny=400;
z=xyz(:,3);
z=reshape(z,nx,ny);z=z';

zn = load('bottom_f.dat'); 


    for i=1:nx
           for j = 1:ny
               if(i<=1+9 || i>=nx-9 ||j<=1+9 || z(j,i)<0 )
                   zn(j,i) = NaN;
               end
           end
    end
      
xmin = 235.78212; xmin=-(360-xmin);
xmax =  235.83759; xmax=-(360-xmax);
ddx=(xmax-xmin)/(nx-1);
ymin = 41.71657; 
ymax = 41.75352;
ddy=(ymax-ymin)/(ny-1);
x=xmin:ddx:xmax;
y=ymin:ddy:ymax;

diff = z-zn; %Deposition depth(negative value means erosion)

for i=1:nx
    for j=1:ny
        if(z(j,i) > 0) 
            z(j,i)=NaN;
        end
    end
end

for i=1:nx
    for j=1:ny
        if(abs(diff(j,i))<5e-2) 
            diff(j,i) = 0; %NaN;
            diff(1:10,:)=NaN; %remove wall value
        end
        
        if(i<1+5 || i>nx-5)
            diff(j,i) = NaN;
        end
        
    end
end

%% BG image
min_x = -(124+12/60+15/60/60); %124��12'15.00"W (-)
max_x = -(124+10/60+30/60/60); %124��10'30.00"W (-)
min_y = 41+43/60+45/60/60; % 41��43'45.00"N
max_y = 41+45/60+0/60/60; % 41��45'0.00"N

figure(13)
img = imread('cc_google1_crop.jpg');
imagesc([min_x max_x],[max_y min_y],img);   

hold on

surf(x,y,diff-0.2,'Edgecolor','None');

hold on

v = [-5. -4. -3. -2. -1. 0. 1.];
[CC,hh]=contour3(x,y,diff,v,'k-');
clabel(CC,hh);
set (hh, 'LineWidth', 1.5); 
colorbar

axis([min_x max_x min_y+0.0013 max_y -Inf Inf])
shading interp
view(0,90)
caxis([-5.5 1.5])
zoom (1);
xlabel('Longitude'), ylabel('Latitude');
set(gca,'ydir','normal'); 
print('-djpeg100 ', 'cc_sed_model.jpg');