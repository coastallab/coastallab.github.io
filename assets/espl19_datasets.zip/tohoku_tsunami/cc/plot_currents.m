clear
clc

%% For Movie
% nImage = 350;
% numframes = nImage;
% hp = 1 * pi / numframes;
% num_frames_per_second = 10;
% dur = numframes / num_frames_per_second;
% aviobj = avifile ( 'a01.avi', 'fps', num_frames_per_second,...
% 		   'compression','Cinepak','quality',100); 

%% Load Exp. Data
%be4 = load('./exp/k_bathy4.txt');
%be8 = load('./exp/k_bathy8.txt');


%% open info file(binary)
% % read header file, which consists of:
fidsurf = fopen('bo_info.dat','r');
skip = fread(fidsurf,1,'int32');
lxly = fread(fidsurf,2,'single');  % read LX and LY
skip = fread(fidsurf,1,'int32');
skip = fread(fidsurf,1,'int32');
nxny = fread(fidsurf,2,'int32');  % read nx and ny
skip = fread(fidsurf,1,'int32');
skip = fread(fidsurf,1,'int32');
dims = fread(fidsurf,2,'int32');  % read dims
skip = fread(fidsurf,1,'int32');
skip = fread(fidsurf,1,'int32');
sx = fread(fidsurf,1,'int32');  % read sx 
skip = fread(fidsurf,1,'int32');
skip = fread(fidsurf,1,'int32');
ex = fread(fidsurf,1,'int32');  % read ex
skip = fread(fidsurf,1,'int32');
skip = fread(fidsurf,1,'int32');
sy = fread(fidsurf,1,'int32');  % read sy 
skip = fread(fidsurf,1,'int32');
skip = fread(fidsurf,1,'int32');
ey = fread(fidsurf,1,'int32');  % read ey 
skip = fread(fidsurf,1,'int32');
skip = fread(fidsurf,1,'int32');
inc = fread(fidsurf,1,'int32');  % read inc(record freq.) 
skip = fread(fidsurf,1,'int32');
fclose(fidsurf);

%% find # of time steps in result files(to be deleted)
load runtime.txt
ntime = length(runtime);
ts = runtime(:);

%% load surface profile file
nx = nxny(1);
ny = nxny(2);
nxloc = ex-sx+1;
nyloc = ey-sy+1;

lx = lxly(1);
ly = lxly(2);
dx = lx/(nx);
dy = ly/(ny);
[x,y] = meshgrid(0:dx:lx-dx,dy:dy:ly);

%% bathymetry file (binary)
fid_d = fopen('depth.dat','r');     
skip = fread(fid_d,1,'int32');
temp = fread(fid_d,[nxloc,nyloc],'float32'); % read depth line by line 
d(sy:ey,sx:ex) = temp';
skip = fread(fid_d,1,'int32');
fclose(fid_d);

kk = 8;

if(kk==1)
  etap_fname='z_0000000'; %FSE
elseif(kk==2)
  etap_fname='u_0000000'; % u
elseif(kk==3)
  etap_fname='v_0000000'; % v
elseif(kk==4)
  etap_fname='vor_0000000'; % vorticity
elseif(kk==5)
  etap_fname='nub_0000000'; % viscosity_breaking 
elseif(kk==6)
  etap_fname='ero_0000000'; % entrainment rate
elseif(kk==7)
  etap_fname='dep_0000000'; % deposition rate
elseif(kk==8)
  etap_fname='ca_0000000'; % concentration
  etap_fnameu='u_0000000'; % u
  etap_fnamev='v_0000000'; % v
  etap_fnameero='ero_0000000'; % v
  etap_fnamedep='dep_0000000'; % v
end

path = '.\res\';
figure(2)

%  y=y*2.5;
%  ly=ly*2.5;
ii = 1;
%% read and generation

for n=702; %710; %6427; %8100 %1:100000 %1:10000 

    clf
    disp(n)
    inc_c=num2str((n-1)*inc);
    fname_c=[path, etap_fname(1:length(etap_fname)-length(inc_c)) inc_c '.dat'];
    fname_cu=[path, etap_fnameu(1:length(etap_fnameu)-length(inc_c)) inc_c '.dat'];
    fname_cv=[path, etap_fnamev(1:length(etap_fnamev)-length(inc_c)) inc_c '.dat'];
    fname_ero=[path, etap_fnameero(1:length(etap_fnameero)-length(inc_c)) inc_c '.dat'];
    fname_dep=[path, etap_fnamedep(1:length(etap_fnamedep)-length(inc_c)) inc_c '.dat'];
    
   
    idc=fopen(fname_c,'r');
    idcu=fopen(fname_cu,'r');
    idcv=fopen(fname_cv,'r');
    idcero=fopen(fname_ero,'r');
    idcdep=fopen(fname_dep,'r');

    skip=fread(idc,1,'int32');
    time=fread(idc,1,'float32')     
    temp=fread(idc,[nxloc,nyloc],'float32');     
    z(sy:ey,sx:ex) = temp';
    skip=fread(idc,1,'int32');
    fclose(idc);
    
    skip=fread(idcu,1,'int32');
    time=fread(idcu,1,'float32')     
    temp=fread(idcu,[nxloc,nyloc],'float32');     
    etacu(sy:ey,sx:ex) = temp';
    skip=fread(idcu,1,'int32');
    fclose(idcu);
    
    skip=fread(idcv,1,'int32');
    time=fread(idcv,1,'float32')     
    temp=fread(idcv,[nxloc,nyloc],'float32');     
    etacv(sy:ey,sx:ex) = temp';
    skip=fread(idcv,1,'int32');
    fclose(idcv);
    
    skip=fread(idcero,1,'int32');
    time=fread(idcero,1,'float32')     
    temp=fread(idcero,[nxloc,nyloc],'float32');     
    ero(sy:ey,sx:ex) = temp';
    skip=fread(idcero,1,'int32');
    fclose(idcero);
    
    skip=fread(idcdep,1,'int32');
    time=fread(idcdep,1,'float32')     
    temp=fread(idcdep,[nxloc,nyloc],'float32');     
    dep(sy:ey,sx:ex) = temp';
    skip=fread(idcdep,1,'int32');
    fclose(idcdep);
    
    
    sp = sqrt(etacu.^2+etacv.^2);
    
    etap_fname1='z_0000000';
    fname_c1=[path, etap_fname1(1:length(etap_fname1)-length(inc_c)) inc_c '.dat'];
    idc1=fopen(fname_c1,'r');

    skip=fread(idc1,1,'int32');
    time=fread(idc1,1,'float32');     
    temp=fread(idc1,[nxloc,nyloc],'float32');     
    eta(sy:ey,sx:ex) = temp';
    skip=fread(idc1,1,'int32');
    fclose(idc1);
    
    iSed = 0.;
    if(iSed==1) %updated bathy
    etap_fnamed='d_000000';
    fname_d=[path, etap_fnamed(1:length(etap_fnamed)-length(inc_c)) inc_c '.dat'];
    fid_d = fopen(fname_d,'r');    
    skip = fread(fid_d,1,'int32');
    time=fread(fid_d,1,'float32');     
    temp=fread(fid_d,[nxloc,nyloc],'float32'); % read depth line by line 
    dn(sy:ey,sx:ex) = temp';
    skip = fread(fid_d,1,'int32');
    fclose(fid_d);
    end
    
    zn = z;
    % NaN value for land (FSE plot only)
    if(kk==1) 
       for i=sx(1):ex(1)
           for j=sy(1):ey(1)
               if(d(j,i)<0)
                   zn(j,i) = NaN;
                   z(j,i) = NaN;
               end
           end
       end
    end

    % Removing Edge Walls in the Visualization
    for i=1:ex
           for j = 1:ey
               if(i<=1+4 || i>=ex-4 ||j<=1+4  )
                   d(j,i) = NaN;
                   z(j,i) = NaN;
                   zn(j,i) = NaN;
                   etacu(j,i) = NaN;
                   etacv(j,i) = NaN;
                   sp(j,i) = NaN;
                   
               end
           end
    end
 
        ss = 0.07;
        ss2 = 0.002;
        margins = [0,0];
        fs = 8.5;
 
        %% subplot 1
         h=subplot(2,2,1);
         p = get(h,'pos'); % 4-element vector [left, bottom, width, height]
         p(3) = p(3) + ss; % add 0.05 units (5% of figure window) 
         p(4) = p(4);
         set(h, 'pos', p);
         %subtightplot(2,2,1,margins)
         pcolor(x,y,sp);
         hold on
         intt=10;
         sca = 500; %scale
         quiver(x(1:intt:ny,1:intt:nx),y(1:intt:ny,1:intt:nx),sca*etacu(1:intt:ny,1:intt:nx),sca*etacv(1:intt:ny,1:intt:nx),'k');
         axis tight
         
         hold on
         surf(x,y,-d*.1+0.003,'CData',zeros(ny,nx,3)+.4,'EdgeAlpha',0.0,'BackFaceLighting','reverselit')
         %surf(xc,yc,-0.2*zc,'CData',zeros(nyc,nxc,3)+.4,'EdgeAlpha',0.0,'BackFaceLighting','reverselit')
         axis equal
         %axis([x(1) x(nx) y(1) y(ny) -Inf Inf])
         %axis([xc(1) xc(nxc) yc(1) yc(nyc) -0.2 0.2])
         axis([2000 4000 1800 3500 -Inf Inf])
         shading interp
         % xlabel('Longitude (deg)');
         % ylabel('Latitude (deg)');
          view(0,90)
         %view(-70,20)
          caxis([0. 2.])
       c=colorbar;
       set(c,'fontsize',8);
       axpos = get(gca,'Position');
       cpos = get(c,'Position');
       cpos(3) = 0.5*cpos(3);
       set(c,'Position',cpos)
       set(gca,'Position',axpos)

        title('Tsunami-induced currents','Fontsize',fs);
         axis off 
         
      %% subplot 2
       h=subplot(2,2,2);
       p = get(h,'pos'); % 4-element vector [left, bottom, width, height]
       p(3) = p(3) + ss; % add 0.05 units (5% of figure window)
       p(4) = p(4);
       set(h, 'pos', p);      
      %subtightplot(2,2,2, margins)
       surf(x,y,z) %,'CData',zeros(ny,nx,1)+0.0,'BackFaceLighting','reverselit')
  	   hold on
       surf(x,y,-d,'CData',zeros(ny,nx,3)+0.4,'BackFaceLighting','reverselit')
       axis equal
       axis tight 
%    axis([0 lx 0 ly -Inf Inf])
       axis([2000 4000 1800 3500 -Inf Inf])
       shading interp
        view(0,90)
       %view(-40,30)
        caxis(0.05*[0. 1.])
        
       c=colorbar;
       set(c,'fontsize',8);
       axpos = get(gca,'Position');
       cpos = get(c,'Position');
       cpos(3) = 0.5*cpos(3);
       set(c,'Position',cpos)
       set(gca,'Position',axpos)
       
       title('Sediment concentration(\it{c})','Fontsize',fs);
    %   axis tight    
       axis off
       
       %set(h,'interpreter','Latex','FontSize',10)

     %% subplot 3
      
       h=subplot(2,2,3);
       p = get(h,'pos'); % 4-element vector [left, bottom, width, height]
       p(3) = p(3) + ss; % add 0.05 units (5% of figure window) 
       p(2) = p(2)+0.07;
       set(h, 'pos', p);   
       
      %subtightplot(2,2,3, margins)
      surf(x,y,ero) %,'CData',zeros(ny,nx,1)+0.0,'BackFaceLighting','reverselit')
  	   hold on
       surf(x,y,-d,'CData',zeros(ny,nx,3)+0.4,'BackFaceLighting','reverselit')
       axis equal
       axis tight 
%    axis([0 lx 0 ly -Inf Inf])
       axis([2000 4000 1800 3500 -Inf Inf])
       shading interp
        view(0,90)
       %view(-40,30)
        caxis(ss2*[0. 1.])
        
        
       c=colorbar;
       set(c,'fontsize',8);
       axpos = get(gca,'Position');
       cpos = get(c,'Position');
       cpos(3) = 0.5*cpos(3);
       set(c,'Position',cpos)
       set(gca,'Position',axpos)
       title('Erosion flux(\it{e})','Fontsize',fs);
    %   axis tight    
       axis off

     %% subplot 4
       h=subplot(2,2,4);
       p = get(h,'pos'); % 4-element vector [left, bottom, width, height]
       p(3) = p(3) + ss; % add 0.05 units (5% of figure window) 
       p(2) = p(2)+0.07;
       set(h, 'pos', p);        
      
      %subtightplot(2,2,4, margins)
      surf(x,y,dep) %,'CData',zeros(ny,nx,1)+0.0,'BackFaceLighting','reverselit')
  	   hold on
       surf(x,y,-d,'CData',zeros(ny,nx,3)+0.4,'BackFaceLighting','reverselit')
       axis equal
       axis tight
%    axis([0 lx 0 ly -Inf Inf])
       axis([2000 4000 1800 3500 -Inf Inf])
       shading interp
        view(0,90)
       %view(-40,30)
        caxis(ss2*[0. 1.])
        
        
       c=colorbar;
       set(c,'fontsize',8);
       axpos = get(gca,'Position');
       cpos = get(c,'Position');
       cpos(3) = 0.5*cpos(3);
       set(c,'Position',cpos)
       set(gca,'Position',axpos)
       title('Deposition flux(\it{d})','Fontsize',fs);
    %   axis tight    
       axis off
     
       %tightfig;
       tii = 34501.0000;
      display(['Time = ',num2str((time+tii)/60/60),' hr since EQ' ]);
       
      fname=['im' num2str(kk*10000+n)];
      print('-djpeg100 ',fname);
    
      pause (0.01)

end   

%% close movie file
%aviobj = close ( aviobj );