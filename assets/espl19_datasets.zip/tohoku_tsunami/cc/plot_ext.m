clc
clear

nx=600;
ny=400;
load 'ext_1pt.mat';

ti(1,:)=ti(1,:)+34501.0000/60;
  
figure(22);
subplot(411)
plot(ti(1,:)/60,ti(2,:),ti(1,:)/60,ti(3,:),'--');
xlabel('Time(hr) after EQ');
ylabel('velocity(m/s)');
legend('\it{u}','\it{v}','orientation','horizontal');
xlim([9.59 18.6]);

subplot(412);
plot(ti(1,:)/60,-ti(7,:));
xlabel('Time(hr) after EQ');
ylabel('depth(m)');
legend('depth');
xlim([9.59 18.6]);

subplot(413);
plot(ti(1,:)/60,ti(4,:));
xlabel('Time(hr) after EQ');
ylabel('concentration(-)');
legend('Concentration');
xlim([9.59 18.6]);

%net-erosional flux(e-d)
subplot(414);
plot(ti(1,:)/60,ti(5,:)-ti(6,:));
xlabel('Time(hr) after EQ');
ylabel('flux(m/s)');
legend('Net erosional flux(\it{e}-d)');
xlim([9.59 18.6]);

% %dep
% subplot(515);
% plot(ti(1,:)/60,ti(6,:));
% xlabel('Time(hr) after EQ');
% ylabel('flux(m/s)');
% legend('depositional flux');
% xlim([9.59 18.6]);