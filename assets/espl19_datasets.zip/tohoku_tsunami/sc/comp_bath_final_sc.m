clc
clear

opengl software

xyz=load('bathy.dep');
nx=200;
ny=400;
z=xyz(:,3);
z=reshape(z,nx,ny);z=z';

zn = load('bottom_f.dat'); 

xmin = 237.98930 ; xmin=-(360-xmin);
xmax =  238.00772; xmax=-(360-xmax);
ddx=(xmax-xmin)/(nx-1);
ymin = 36.94070; 
ymax = 36.97764;
ddy=(ymax-ymin)/(ny-1);
x=xmin:ddx:xmax;
y=ymin:ddy:ymax;
y=y-0.00015;
x=x+0.0001;
% %% bathymetry file (binary)
% fid_d = fopen('depth.dat','r');     
% skip = fread(fid_d,1,'int32');
% temp = fread(fid_d,[nx,ny],'float32'); % read depth line by line 
% d(sy:ey,sx:ex) = temp';
% skip = fread(fid_d,1,'int32');
% fclose(fid_d);

    for i=1:nx
           for j = 1:ny
               if(i<=1+9 || i>=nx-9 ||j<=1+9 || z(j,i)<0 )
                   %z(j,i) = NaN;                   
                   zn(j,i) = NaN;
               end
           end
    end
    

% for i=1:nx
%     for j=1:ny
%         if(z(j,i) < 0) 
%             z(j,i)=NaN;
%         end
%     end
% end

diff = z-zn; %Deposition depth(negative value means erosion)


for i=1:nx
    for j=1:ny
        %if(abs(diff(j,i))<1e-3) 
        %    diff(j,i) = NaN;
        %    diff(1:5,:)=NaN; %remove wall value
        %end
        
        if(i<1+5 || i>nx-5)
            diff(j,i) = NaN;
        end
        
        if(z(j,i) < 0) 
            %ero(j,i)=NaN;
        end
    end
end

%% BG image
min_x = -(122+0/60+15/60/60); %122�� 0'15.00"W (-)
max_x = -(122+0/60+0/60/60); %122�� 0'0.00"W (-)
min_y = 36+57/60+35/60/60; %36��57'35.00"N
max_y = 36+57/60+45/60/60; %36��57'45.00"N

figure(28)
img = imread('sc_google2_crop.jpg');
%imshow(img);
imagesc([min_x max_x],[max_y min_y],img);   

hold on

surf(x,y,diff-0.01,'Edgecolor','None');

hold on

v = [-1. 0. 1. 2. 3. 4];
[CC,hh]=contour3(x,y,diff,v,'k-');
%[CC,hh]=contourf(x,y,diff,v);
%[CC,hh]=contour(x,y,diff);
clabel(CC,hh);
set (hh, 'LineWidth', 1.5); 
colorbar
%axis equal  
axis([min_x max_x min_y+0.0001 max_y -Inf Inf])
shading interp

view(0,90)
caxis([-1.5 4.])
zoom (1);
xlabel('Longitude'), ylabel('Latitude');
set(gca,'ydir','normal'); 
print('-djpeg100 ', ['SC_bathy_change_10m_spng_phil.jpg']);