clear
clc

%% Load Exp. Data
u1 = load('./exp/u1_exp.txt');
u2 = load('./exp/u2_exp.txt');
u3 = load('./exp/u3_exp.txt');
u6 = load('./exp/u6_exp.txt');
u7 = load('./exp/u7_exp.txt');
%be8 = load('./exp/k_bathy8.txt');


ts = load ('ts.txt');
d = 0.1; %thickness of bed

t = ts(:,1);
ms = 4.5;

figure(19)
subplot(511)
plot(t,ts(:,2)+d,u1(:,1),u1(:,2),'.','MarkerSize',ms)
legend('Numerical','Measured','orientation','horizontal');
xlim([0 12]);
ylim([0.05 0.25]);
ylabel('Surface level(m)')
set(gca,'xtick',[])
text(11.2, 0.08, 'U1')
 
subplot(512)
plot(t,ts(:,3)+d,u2(:,1),u2(:,2),'.','MarkerSize',ms)
%legend('Numerical(U2)','Measured');
xlim([0 12]);
ylim([0.05 0.2]);
ylabel('Surface level(m)')
set(gca,'xtick',[])
text(11.2, 0.08, 'U2')

subplot(513)
plot(t,ts(:,4)+d,u3(:,1),u3(:,2),'.','MarkerSize',ms)
%legend('Numerical(U3)','Measured');
xlim([0 12]);
ylim([0.05 0.2]);
ylabel('Surface level(m)')
set(gca,'xtick',[])
text(11.2, 0.08, 'U3')


subplot(514)
plot(t,ts(:,5)+d,u6(:,1),u6(:,2),'.','MarkerSize',ms)
%legend('Numerical(U6)','Measured');
xlim([0 12]);
ylim([0.05 0.2]);
ylabel('Surface level(m)')
set(gca,'xtick',[])
text(11.2, 0.08, 'U6')

subplot(515)
plot(t,ts(:,6)+d,u7(:,1),u7(:,2),'.','MarkerSize',ms)
%legend('Numerical(U7)','Measured');
xlim([0 12]);
ylim([0.05 0.2]);
ylabel('Surface level(m)')
%set(gca,'xtick',[])
text(11.2, 0.08, 'U7')

