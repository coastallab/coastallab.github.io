clear
clc

%% Load Exp. Data
b1 = load('./exp/b1_exp.txt');
b3 = load('./exp/b3_exp.txt');
b5 = load('./exp/b5_exp.txt');
b7 = load('./exp/b7_exp.txt');
b9 = load('./exp/b7_exp.txt');

bed = load ('bed_20sec.txt');
d = 0.1; %thickness of bed

%x = 0.05+0.005:0.01:0.6-0.05-0.005;
x = 0+0.005:0.01:0.5-0.005;
ms = 4.5; 

 figure(11)
 subplot(511)
 plot(x,-bed(55:-1:6,5+400+10)+d,b1(:,1),b1(:,2),'.','MarkerSize',ms)
 legend('Numerical','Measured','orientation','horizontal');
 xlim([0 0.5]);
 ylim([0.05 0.151]);
 ylabel('Bed level(m)')
 set(gca,'xtick',[])
 text(0.01, 0.07, 'At CS1')

 subplot(512)
 plot(x,-bed(55:-1:6,5+400+20)+d,b3(:,1),b3(:,2),'.','MarkerSize',ms)
 %legend('Numerical(B3)','Measured');
 xlim([0 0.5]);
 ylim([0.05 0.15]);
 ylabel('Bed level(m)')
 set(gca,'xtick',[])
 text(0.01, 0.07, 'At CS3')
  
 subplot(513)
 plot(x,-bed(55:-1:6,5+400+30)+d,b5(:,1),b5(:,2),'.','MarkerSize',ms)
 %legend('Numerical(B5)','Measured');
 xlim([0 0.5]);
 ylim([0.05 0.15]);
 ylabel('Bed level(m)')
 set(gca,'xtick',[])
 text(0.01, 0.07, 'At CS5')
 
 subplot(514)
 plot(x,-bed(55:-1:6,5+400+40)+d,b7(:,1),b7(:,2),'.','MarkerSize',ms)
 %legend('Numerical(B7)','Measured');
 xlim([0 0.5]);
 ylim([0.05 0.15]);
 ylabel('Bed level(m)')
 set(gca,'xtick',[])
 text(0.01, 0.07, 'At CS7')
 
 subplot(515)
 plot(x,-bed(55:-1:6,5+400+50)+d,b9(:,1),b9(:,2),'.','MarkerSize',ms)
 %legend('Numerical(B9)','Measured');
 xlim([0 0.5]);
 ylim([0.05 0.15]);
 ylabel('Bed level(m)')
 %set(gca,'xtick',[])
 text(0.01, 0.07, 'At CS9')
 %xlabel('Time(sec)')
  

