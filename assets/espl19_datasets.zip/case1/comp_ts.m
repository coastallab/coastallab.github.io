clear
clc

exp_5d=load('.\exp\5t_d.txt');
exp_5eta=load('.\exp\5t_eta.txt');

exp_7d=load('.\exp\7t_d.txt');
exp_7eta=load('.\exp\7t_eta.txt');

exp_10d=load('.\exp\10t_d.txt');
exp_10eta=load('.\exp\10t_eta.txt');

eta_5t=load('eta_5t.txt');
bed_5t=load('bed_5t.txt');

eta_7t=load('eta_7t.txt');
bed_7t=load('bed_7t.txt');

eta_10t=load('eta_10t.txt');
bed_10t=load('bed_10t.txt');

x=-1.25:0.005:1.25-0.005;

figure(1)

subplot(311)
plot(x,eta_5t(2,:),exp_5eta(:,1),exp_5eta(:,2),'o',...
     x,-bed_5t(2,:),'--',exp_5d(:,1),exp_5d(:,2),'s',...
     'MarkerSize',5,'MarkerEdgeColor','k')
ylim([-0.03 0.12])
xlim([-1 1]);
title('t=0.505sec')
%xlabel('x(m)');
%ylabel('Bed and Surface Elevation(m)')
hleg=legend('Calculated FSE','Measured FSE','Calculated Bed Profile','Measured Bed Profile');
% Make the text of the legend italic and color it brown
set(hleg,'FontSize',8,'box','off')
%set(hleg,'FontAngle','italic','TextColor',[.3 .2 .1])


%'fontsize',5);

subplot(312)
plot(x,eta_7t(2,:),exp_7eta(:,1),exp_7eta(:,2),'o',...
     x,-bed_7t(2,:),'--',exp_7d(:,1),exp_7d(:,2),'s',...
     'MarkerSize',5,'MarkerEdgeColor','k')
ylim([-0.03 0.12])
xlim([-1 1]);
title('t=0.757sec')
%xlabel('x(m)');
ylabel('Bed and Surface Elevation(m)')

subplot(313)
plot(x,eta_10t(2,:),exp_10eta(:,1),exp_10eta(:,2),'o',...
     x,-bed_10t(2,:),'--',exp_10d(:,1),exp_10d(:,2),'s',...
     'MarkerSize',5,'MarkerEdgeColor','k')
ylim([-0.03 0.12])
xlim([-1 1]);
title('t=1.010sec')
xlabel('x(m)');
%ylabel('Bed and Surface Elevation(m)')
